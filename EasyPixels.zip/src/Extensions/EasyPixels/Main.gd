extends Node

var gradient_tool_scene := "res://src/Extensions/EasyPixels/GradientTool.tscn"
var sparkle_tool_scene := "res://src/Extensions/EasyPixels/SparkleTool.tscn"


func _enter_tree() -> void:
	ExtensionsApi.tools.add_tool("GradientLine", "Gradient Line", gradient_tool_scene)
	ExtensionsApi.tools.add_tool("EasySparkle", "Easy Sparkle", sparkle_tool_scene)


func _exit_tree() -> void:
	ExtensionsApi.tools.remove_tool("GradientLine")
	ExtensionsApi.tools.remove_tool("EasySparkle")
